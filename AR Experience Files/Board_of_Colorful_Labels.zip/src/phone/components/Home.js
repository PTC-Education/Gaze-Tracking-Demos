// This function is triggered when the experience is first opened
$scope.$on('$ionicView.afterEnter',function(array){
  $scope.classArray = ['red-label', 'orange-label', 'yellow-label', 'green-label', 'blue-label', 'purple-label', 'black-label', 'brown-label', 'grey-label', 'white-label']; // An array with all the classes defined in the 'Application' CSS tab
  $scope.shuffle($scope.classArray); // Calls the function to randomize the array
  
  // Initializes all timers
  $scope.experienceGazeTimer = 0; // Duration of experience
  $scope.object1GazeTimer = 0; // Duration of gaze @ object 1
  $scope.object2GazeTimer = 0; // Duration of gaze @ object 2
  $scope.object3GazeTimer = 0; // Duration of gaze @ object 3
  $scope.object4GazeTimer = 0; // Duration of gaze @ object 4
  $scope.object5GazeTimer = 0; // Duration of gaze @ object 5
  $scope.object6GazeTimer = 0; // Duration of gaze @ object 6
  $scope.object7GazeTimer = 0; // Duration of gaze @ object 7
  $scope.object8GazeTimer = 0; // Duration of gaze @ object 8
  $scope.object9GazeTimer = 0; // Duration of gaze @ object 9
  $scope.object10GazeTimer = 0; // Duration of gaze @ object 10
  $scope.extraTime = 0; // Duration of gaze @ no objects 
  $scope.objectBeingViewed = 'N/A'; // Object currently being viewed
})

// This function shuffles the elements within the array its given
$scope.shuffle = function(array){
  var currentIndex = array.length,  randomIndex;
  
  // While there remain elements to shuffle...
  while (0 !== currentIndex) {
    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    
    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }
  // Sets the class (style) of each label according to the newly randomized array
  $scope.setWidgetProp('3DLabel-1', 'class', array[0]);
  $scope.setWidgetProp('3DLabel-2', 'class', array[1]);
  $scope.setWidgetProp('3DLabel-3', 'class', array[2]);
  $scope.setWidgetProp('3DLabel-4', 'class', array[3]);
  $scope.setWidgetProp('3DLabel-5', 'class', array[4]);
  $scope.setWidgetProp('3DLabel-6', 'class', array[5]);
  $scope.setWidgetProp('3DLabel-7', 'class', array[6]);
  $scope.setWidgetProp('3DLabel-8', 'class', array[7]);
  $scope.setWidgetProp('3DLabel-9', 'class', array[8]);
  $scope.setWidgetProp('3DLabel-10', 'class', array[9]);
}

// This function is triggered when tracking is established
$scope.$on('trackingacquired',function() {
  var timingInterval = 500; // milliseconds
  var focusThreshold = 0.9; // for dot product
      
  // The code below is for processing data at a set interval
  $scope.getGazeTracking = setInterval(function() {   
    $scope.$apply(function(){ 
      // This code is optional and used when you want to log gaze tracking data in ThingWorx
      var TWXthingID = 'JF_BoardOfColorfulLabels_DT'; // The name of your 'Thing' in ThingWorx
      var serviceName = 'getTimers'; // The name of the ThingWorx service your are executing 
      
      // Creates an array with the dot product values for all objects in the experience
      var focusArray = [$scope.object1Focus, $scope.object2Focus, $scope.object3Focus, $scope.object4Focus, $scope.object5Focus, $scope.object6Focus, $scope.object7Focus, $scope.object8Focus, $scope.object9Focus, $scope.object10Focus];
      
      var maxIndex = $scope.indexOfMax(focusArray); // Calls function to find the index of the array's maximum value
            
      $scope.experienceGazeTimer = $scope.experienceGazeTimer + (timingInterval / 1000); // Increments experience timer
                
      // Increments the timer of the object closest to the center of the screen and defines the object being viewed
         // Objects must have the maximum dot product and have a dot product above a set threshold to ensure they're actually on-screen
      if (maxIndex == 1 && $scope.object1Focus >= focusThreshold) {
        $scope.object1GazeTimer = $scope.object1GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-1'; 
      }
      else if (maxIndex == 2 && $scope.object2Focus >= focusThreshold) {
        $scope.object2GazeTimer = $scope.object2GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-2'; 
      }
      else if (maxIndex == 3 && $scope.object3Focus >= focusThreshold) {
        $scope.object3GazeTimer = $scope.object3GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-3'; 
      }
      else if (maxIndex == 4 && $scope.object4Focus >= focusThreshold) {
        $scope.object4GazeTimer = $scope.object4GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-4'; 
      }
      else if (maxIndex == 5 && $scope.object5Focus >= focusThreshold) {
        $scope.object5GazeTimer = $scope.object5GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-5'; 
      }
      else if (maxIndex == 6 && $scope.object6Focus >= focusThreshold) {
        $scope.object6GazeTimer = $scope.object6GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-6'; 
      }
      else if (maxIndex == 7 && $scope.object7Focus >= focusThreshold) {
        $scope.object7GazeTimer = $scope.object7GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-7'; 
      }
      else if (maxIndex == 8 && $scope.object8Focus >= focusThreshold) {
        $scope.object8GazeTimer = $scope.object8GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-8'; 
      }
      else if (maxIndex == 9 && $scope.object9Focus >= focusThreshold) {
        $scope.object9GazeTimer = $scope.object9GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-9'; 
      }
      else if (maxIndex == 10 && $scope.object10Focus >= focusThreshold) {
        $scope.object10GazeTimer = $scope.object10GazeTimer + (timingInterval / 1000);
        $scope.objectBeingViewed = 'object-10'; 
      }
      else {// If no objects are close to center screen, increment extra timer and define that no objects are being viewed
       $scope.extraTime = $scope.extraTime + (timingInterval / 1000);
       $scope.objectBeingViewed = 'N/A'; 
      }
           
      // Defining objects to make passing data to ThingWorx much easier
      const obj1Data = {
        Class: $scope.classArray[0],
        Distance: $scope.object1Distance.toFixed(4),
        DotP: $scope.object1Focus.toFixed(5),
        Timer: $scope.object1GazeTimer
      };
      const obj2Data = {
        Class: $scope.classArray[1],
        Distance: $scope.object2Distance.toFixed(4),
        DotP: $scope.object2Focus.toFixed(5),
        Timer: $scope.object2GazeTimer
      };
      const obj3Data = {
        Class: $scope.classArray[2],
        Distance: $scope.object3Distance.toFixed(4),
        DotP: $scope.object3Focus.toFixed(5),
        Timer: $scope.object3GazeTimer
      };
      const obj4Data = {
        Class: $scope.classArray[3],
        Distance: $scope.object4Distance.toFixed(4),
        DotP: $scope.object4Focus.toFixed(5),
        Timer: $scope.object4GazeTimer
      };
      const obj5Data = {
        Class: $scope.classArray[4],
        Distance: $scope.object5Distance.toFixed(4),
        DotP: $scope.object5Focus.toFixed(5),
        Timer: $scope.object5GazeTimer
      };
      const obj6Data = {
        Class: $scope.classArray[5],
        Distance: $scope.object6Distance.toFixed(4),
        DotP: $scope.object6Focus.toFixed(5),
        Timer: $scope.object6GazeTimer
      };
      const obj7Data = {
        Class: $scope.classArray[6],
        Distance: $scope.object7Distance.toFixed(4),
        DotP: $scope.object7Focus.toFixed(5),
        Timer: $scope.object7GazeTimer
      };
      const obj8Data = {
        Class: $scope.classArray[7],
        Distance: $scope.object8Distance.toFixed(4),
        DotP: $scope.object8Focus.toFixed(5),
        Timer: $scope.object8GazeTimer
      };
      const obj9Data = {
        Class: $scope.classArray[8],
        Distance: $scope.object9Distance.toFixed(4),
        DotP: $scope.object9Focus.toFixed(5),
        Timer: $scope.object9GazeTimer
      };
      const obj10Data = {
        Class: $scope.classArray[9],
        Distance: $scope.object10Distance.toFixed(4),
        DotP: $scope.object10Focus.toFixed(5),
        Timer: $scope.object10GazeTimer
      };
       const otherData = {
         totalTime: $scope.experienceGazeTimer.toFixed(1),
         extraTime:$scope.extraTime.toFixed(2),
         objectBeingViewed: $scope.objectBeingViewed
       }      
      
        // Contains the JSON data for the service inputs
      var serviceParameters = {'object1': obj1Data, 'object2': obj2Data, 'object3': obj3Data, 'object4': obj4Data, 'object5': obj5Data, 'object6': obj6Data, 'object7': obj7Data, 'object8': obj8Data, 'object9': obj9Data, 'object10': obj10Data, 'otherData': otherData};
      
      // Calls a ThingWorx service and inputs all the parameters defined above
      twx.app.fn.triggerDataService(TWXthingID, serviceName, serviceParameters);
    });  
 }, timingInterval);
})

// This function is triggered when tracking is lost
$scope.$on('trackinglost',function() {
  clearInterval($scope.getGazeTracking); // Stops the interval function that increments the timers
})

// Gets the index of the element with the highest value. This tells us which object is closest to the center of the screen.
$scope.indexOfMax = function(arr) {
  var max = arr[0];
  var maxIndex = 0;
  
  // Indexes through all array elements and records the index of the element with the highest value.
  for (var i = 1; i < arr.length; i++) {
    if (arr[i] > max) {
      maxIndex = i;
      max = arr[i];
    }
  }
  return maxIndex + 1; // Returns value + 1 for ease of programming
}

/*
A look into how to use the tacking even for features such as gaze tracking
BE SURE TO ENABLE TRACKING EVENTS IN '3D CONTAINER'
*/

/*
Firstly, the 'tracking' event. This is called from the core viewer, and it passed the following three elements that make up the viewpoint of the viewer.

arg.position = vector(3) xyz positional offset from the root tracker
arg.gaze = vector(3) defining the direction of the head - think of this as an arrow pointing from the center of the head/camera out through the eyes 
arg.up = vector(3) defining the up direction - think of this as an arrow from the center of the head/camera pointing up through the head

As the device moves, these values change and this event is fired

The up and gaze vectors should already be normalized meaning that are unit vectors (length = 1). it is important during vector/matrix maths to keep certain vectors normalised.

It is VERY IMPORTANT not to spend too long in this function as it is a callback from the main render thread. Instead, collect the values and perhaps use an interval timer or $timeout to complete any functionality. 
*/

// This function watches for every time the experience 'tracking' event is fired and executes each time
$scope.$on('tracking', function(evt, arg) {
  
  // Let's start by extracting the values into some helper objects
  var headpos  = new Vector4().Set3a(arg.position);	// Position as a vector
  var headgaze = new Vector4().Set3a(arg.gaze); // Gaze as a vector
  var headup   = new Vector4().Set3a(arg.up);
  
  // The code below is for determining the user's focus on and distance to object 1
  var gazeVector1 = new Vector4().Set3(($scope.view.wdg['3DLabel-1']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-1']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object1Distance = gazeVector1.Length();  // Defines the user's distance to object 1
  var gazeVectorNorm1 = gazeVector1.Normalize(); //Normalizes the vector for the dot product
  $scope.object1Focus = headgaze.DotP(gazeVectorNorm1); // Takes the dot product of the vector to object 1 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 2
  var gazeVector2 = new Vector4().Set3(($scope.view.wdg['3DLabel-2']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-2']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-2']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object2Distance = gazeVector2.Length(); // Defines the user's distance to object 2
  var gazeVectorNorm2 = gazeVector2.Normalize(); //Normalizes the vector for the dot product
  $scope.object2Focus = headgaze.DotP(gazeVectorNorm2); // Takes the dot product of the vector to object 2 and user's gaze vector

// The code below is for determining the user's focus on and distance to object 3
  var gazeVector3 = new Vector4().Set3(($scope.view.wdg['3DLabel-3']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-3']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-3']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object3Distance = gazeVector3.Length(); // Defines the user's distance to object 3
  var gazeVectorNorm3 = gazeVector3.Normalize(); //Normalizes the vector for the dot product
  $scope.object3Focus = headgaze.DotP(gazeVectorNorm3); // Takes the dot product of the vector to object 3 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 4
  var gazeVector4 = new Vector4().Set3(($scope.view.wdg['3DLabel-4']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-4']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-4']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object4Distance = gazeVector4.Length(); // Defines the user's distance to object 4
  var gazeVectorNorm4 = gazeVector4.Normalize(); //Normalizes the vector for the dot product
  $scope.object4Focus = headgaze.DotP(gazeVectorNorm4); // Takes the dot product of the vector to object 4 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 5
  var gazeVector5 = new Vector4().Set3(($scope.view.wdg['3DLabel-5']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-5']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-5']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object5Distance = gazeVector5.Length(); // Defines the user's distance to object 5
  var gazeVectorNorm5 = gazeVector5.Normalize(); //Normalizes the vector for the dot product
  $scope.object5Focus = headgaze.DotP(gazeVectorNorm5); // Takes the dot product of the vector to object 5 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 6
  var gazeVector6 = new Vector4().Set3(($scope.view.wdg['3DLabel-6']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-6']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-6']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object6Distance = gazeVector6.Length(); // Defines the user's distance to object 6
  var gazeVectorNorm6 = gazeVector6.Normalize(); //Normalizes the vector for the dot product
  $scope.object6Focus = headgaze.DotP(gazeVectorNorm6); // Takes the dot product of the vector to object 6 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 7
  var gazeVector7 = new Vector4().Set3(($scope.view.wdg['3DLabel-7']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-7']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-7']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object7Distance = gazeVector7.Length(); // Defines the user's distance to object 7
  var gazeVectorNorm7 = gazeVector7.Normalize(); //Normalizes the vector for the dot product
  $scope.object7Focus = headgaze.DotP(gazeVectorNorm7); // Takes the dot product of the vector to object 7 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 8
  var gazeVector8 = new Vector4().Set3(($scope.view.wdg['3DLabel-8']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-8']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-8']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object8Distance = gazeVector8.Length(); // Defines the user's distance to object 8
  var gazeVectorNorm8 = gazeVector8.Normalize(); //Normalizes the vector for the dot product
  $scope.object8Focus = headgaze.DotP(gazeVectorNorm8); // Takes the dot product of the vector to object 8 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 9
  var gazeVector9 = new Vector4().Set3(($scope.view.wdg['3DLabel-9']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-9']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-9']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object9Distance = gazeVector9.Length(); // Defines the user's distance to object 9
  var gazeVectorNorm9 = gazeVector9.Normalize(); //Normalizes the vector for the dot product
  $scope.object9Focus = headgaze.DotP(gazeVectorNorm9); // Takes the dot product of the vector to object 9 and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to object 1-
  var gazeVector10 = new Vector4().Set3(($scope.view.wdg['3DLabel-10']['x'] - arg.position[0]),($scope.view.wdg['3DLabel-10']['y'] - arg.position[1]),($scope.view.wdg['3DLabel-10']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the object's coordinates
  $scope.object10Distance = gazeVector10.Length(); // Defines the user's distance to object 10
  var gazeVectorNorm10 = gazeVector10.Normalize(); //Normalizes the vector for the dot product
  $scope.object10Focus = headgaze.DotP(gazeVectorNorm10); // Takes the dot product of the vector to object 10 and user's gaze vector
});




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Steve's simple matrix/vector library
function Matrix4() {
  this.m = [ [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]];

  this.Set3V = function(v1,v2,v3) {
    this.m[0][0] = v1.v[0];
    this.m[0][1] = v1.v[1];
    this.m[0][2] = v1.v[2];

    this.m[1][0] = v2.v[0];
    this.m[1][1] = v2.v[1];
    this.m[1][2] = v2.v[2];

    this.m[2][0] = v3.v[0];
    this.m[2][1] = v3.v[1];
    this.m[2][2] = v3.v[2];
    return this;
  }
  this.Set4V = function(v1,v2,v3,v4) {
    this.m[0][0] = v1.v[0];
    this.m[0][1] = v1.v[1];
    this.m[0][2] = v1.v[2];
    this.m[1][0] = v2.v[0];
    this.m[1][1] = v2.v[1];
    this.m[1][2] = v2.v[2];
    this.m[2][0] = v3.v[0];
    this.m[2][1] = v3.v[1];
    this.m[2][2] = v3.v[2];
    this.m[3][0] = v4.v[0];
    this.m[3][1] = v4.v[1];
    this.m[3][2] = v4.v[2];
    return this;
  }

  this.Translate = function (x, y, z) {
    var t = [ [1, 0, 0, 0],
             [0, 1, 0, 0],
             [0, 0, 1, 0],
             [x, y, z, 1]];
    return this.Multiply(t);
  }

  this.TranslateV4 = function (v) {  // takes a Vector4
    var t = [ [1, 0, 0, 0],
              [0, 1, 0, 0],
              [0, 0, 1, 0],
              [v.v[0], v.v[1], v.v[2], 1]];
    return this.Multiply(t);
  }

  this.Scale = function (x, y, z) {
    var s = [ [x, 0, 0, 0],
             [0, y, 0, 0],
             [0, 0, z, 0],
             [0, 0, 0, 1]];
    return this.Multiply(s);
  }

  this.Rotate = function (axis, angle) {
    var s  = Math.sin(angle);
    var c0 = Math.cos(angle);
    var c1 = 1 - c0;

    // assume normalised input vector
    var u = axis[0];
    var v = axis[1];
    var w = axis[2];

    var r = [
      [(u * u * c1) + c0,      (u * v * c1) - (w * s), (u * w * c1) + (v * s), 0],
      [(u * v * c1) + (w * s), (v * v * c1) + c0,      (v * w * c1) - (u * s), 0],
      [(u * w * c1) - (v * s), (v * w * c1) + (u * s), (w * w * c1) + c0,      0],
      [0,                      0,                      0,                      1]
    ];


    return this.Multiply(r);
  }

  this.Multiply = function (b) {
    var dst = [ 
      [   ((this.m[0][0] * b[0][0]) + (this.m[0][1] * b[1][0]) + (this.m[0][2] * b[2][0]) + (this.m[0][3] * b[3][0])),
       ((this.m[0][0] * b[0][1]) + (this.m[0][1] * b[1][1]) + (this.m[0][2] * b[2][1]) + (this.m[0][3] * b[3][1])),
       ((this.m[0][0] * b[0][2]) + (this.m[0][1] * b[1][2]) + (this.m[0][2] * b[2][2]) + (this.m[0][3] * b[3][2])),
       ((this.m[0][0] * b[0][3]) + (this.m[0][1] * b[1][3]) + (this.m[0][2] * b[2][3]) + (this.m[0][3] * b[3][3])) ],
      [   ((this.m[1][0] * b[0][0]) + (this.m[1][1] * b[1][0]) + (this.m[1][2] * b[2][0]) + (this.m[1][3] * b[3][0])),
       ((this.m[1][0] * b[0][1]) + (this.m[1][1] * b[1][1]) + (this.m[1][2] * b[2][1]) + (this.m[1][3] * b[3][1])),
       ((this.m[1][0] * b[0][2]) + (this.m[1][1] * b[1][2]) + (this.m[1][2] * b[2][2]) + (this.m[1][3] * b[3][2])),
       ((this.m[1][0] * b[0][3]) + (this.m[1][1] * b[1][3]) + (this.m[1][2] * b[2][3]) + (this.m[1][3] * b[3][3])) ],
      [   ((this.m[2][0] * b[0][0]) + (this.m[2][1] * b[1][0]) + (this.m[2][2] * b[2][0]) + (this.m[2][3] * b[3][0])),
       ((this.m[2][0] * b[0][1]) + (this.m[2][1] * b[1][1]) + (this.m[2][2] * b[2][1]) + (this.m[2][3] * b[3][1])),
       ((this.m[2][0] * b[0][2]) + (this.m[2][1] * b[1][2]) + (this.m[2][2] * b[2][2]) + (this.m[2][3] * b[3][2])),
       ((this.m[2][0] * b[0][3]) + (this.m[2][1] * b[1][3]) + (this.m[2][2] * b[2][3]) + (this.m[2][3] * b[3][3])) ],
      [   ((this.m[3][0] * b[0][0]) + (this.m[3][1] * b[1][0]) + (this.m[3][2] * b[2][0]) + (this.m[3][3] * b[3][0])),
       ((this.m[3][0] * b[0][1]) + (this.m[3][1] * b[1][1]) + (this.m[3][2] * b[2][1]) + (this.m[3][3] * b[3][1])),
       ((this.m[3][0] * b[0][2]) + (this.m[3][1] * b[1][2]) + (this.m[3][2] * b[2][2]) + (this.m[3][3] * b[3][2])),
       ((this.m[3][0] * b[0][3]) + (this.m[3][1] * b[1][3]) + (this.m[3][2] * b[2][3]) + (this.m[3][3] * b[3][3])) ]];
    this.m = dst;
    return this;
  }

  this.makeOrtho = function(left, right, bottom, top, znear, zfar) {
    var X = -(right + left) / (right - left);
    var Y = -(top + bottom) / (top - bottom);
    var Z = -(zfar + znear) / (zfar - znear);
    var A = 2 / (right - left);
    var B = 2 / (top - bottom);
    var C = -2 / (zfar - znear);

    this.m = [[A, 0, 0, 0],
              [0, B, 0, 0],
              [0, 0, C, 0],
              [X, Y, Z, 1]];
    return this;
  }

  this.makePerspective = function(fovy, aspect, znear, zfar) {
    var ymax = znear * Math.tan(fovy * Math.PI / 360.0);
    var ymin = -ymax;
    var xmin = ymin * aspect;
    var xmax = ymax * aspect;

    this.makeFrustum(xmin, xmax, ymin, ymax, znear, zfar);
    return this;
  }

  this.makeFrustum = function(left, right, bottom, top, znear, zfar) {
    var X = 2 * znear / (right - left);
    var Y = 2 * znear / (top - bottom);
    var A = (right + left) / (right - left);
    var B = (top + bottom) / (top - bottom);
    var C = -(zfar + znear) / (zfar - znear);
    var D = -2 * zfar * znear / (zfar - znear);

    this.m = [[X, 0, 0, 0],
              [0, Y, 0, 0],
              [A, B, C, -1],
              [0, 0, D, 1]];
    return this;
  }
  
  this.makeLookat = function(at,from,up) {
    var lookv  = at.Sub(from).Normalize();
    var xd     = up.Normalize().CrossP(lookv.Normalize());
    var nup    = lookv.CrossP(xd).Normalize(); // recalc up
    var lookat = new Matrix4().Set4V(xd,nup,lookv,from);
    return lookat;
  }
    
  this.makePose = function(at,gaze,up) {
    var xd   = up.Normalize().CrossP(gaze.Normalize());
    var nup  = gaze.CrossP(xd).Normalize(); // recalc up
    var pose = new Matrix4().Set4V(xd,nup,gaze,at);
    return pose;
  }
  
  this.Flatten = function () {
    var f = [];
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < 4 ; j++) {
        f.push(this.m[i][j]);
      }
    }
    return f;
  }

  this.ToString = function () {
    var s = '';
    for (var i = 0; i < 4; i++) {
      s = s.concat(this.m[i].toString());
      s = s.concat(',');
    }
    // now replace the commas with spaces
    s = s.replace(/,/g, ' ');
    return s;
  }

  this.ToEuler = function(toDeg) {
    
        // assumes the upper 3x3 of m is a pure rotation matrix (i.e, unscaled)
        var m11 = this.m[0][0], m12 = this.m[1][0], m13 = this.m[2][0];
        var m21 = this.m[0][1], m22 = this.m[1][1], m23 = this.m[2][1];
        var m31 = this.m[0][2], m32 = this.m[1][2], m33 = this.m[2][2];
        var sy = Math.sqrt(m32 * m32 + m33 * m33);
     
        var singular = (sy < 0.000001) ? true : false;
        var _x, _y, _z;
        
        if (singular === false) {
            _x = Math.atan2(  m32, m33);
            _y = Math.atan2(- m31, sy);
            _z = Math.atan2(  m21, m11);
        } else {
            _x = Math.atan2(- m32, m22);
            _y = Math.atan2(- m31, sy);
            _z = 0;
        }
        
        // convert to degrees?
        var deg = (toDeg != undefined) ? 180.0/Math.PI : 1; 
        var attitude = deg * _x; // make this left handed
        var heading  = deg * _y;
        var bank     = deg * _z;
        
        return { 
          attitude:attitude, 
          heading :heading, 
          bank    :bank 
        };
  }
  
  this.ToPosEuler = function(toDeg) {
    var clamp = function(x) {
      if (Math.abs(x) < 1e-6)
        return 0;
      else 
        return x;
    }

    var rot = this.ToEuler(toDeg);
        
    var simple = {};
    simple.pos = new Vector4().Set3(clamp(this.m[3][0]), clamp(this.m[3][1]), clamp(this.m[3][2]));
    simple.rot = new Vector4().Set3(rot.attitude, rot.heading, rot.bank);
    return simple;
  }

}

// quick way to do perspective matrices
function MatrixP() { }
MatrixP.prototype = new Matrix4()
function MatrixP(fovy, aspect, znear, zfar) {
    this.makePerspective(fovy, aspect, znear, zfar);
}

// quick way to do orthographic matrices
function MatrixO() { }
MatrixO.prototype = new Matrix4()
function MatrixO(left, right, bottom, top, znear, zfar) {
    this.makeOrtho(left, right, bottom, top, znear, zfar);
}


function Vector4() {
  this.v = [0, 0, 0, 1];

  this.X = function() { return this.v[0] }
  this.Y = function() { return this.v[1] }
  this.Z = function() { return this.v[2] }
  this.W = function() { return this.v[3] }

  this.Set3 = function (x, y, z) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    return this;
  }

  this.Set3a = function (a) {
    this.v[0] = a[0];
    this.v[1] = a[1];
    this.v[2] = a[2];
    return this;
  }

  this.Set4 = function (x, y, z, w) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    this.v[3] = w;
    return this;
  }

  this.SetV4 = function (v) {
    this.v[0] = v.v[0];
    this.v[1] = v.v[1];
    this.v[2] = v.v[2];
    this.v[3] = v.v[3];
    return this;
  }

  this.Length = function () {
    var hyp = (this.v[0] * this.v[0]) + (this.v[1] * this.v[1]) + (this.v[2] * this.v[2]);
    var rad = (hyp > 0) ? Math.sqrt(hyp) : 0;
    return rad;
  }

  this.Normalize = function () {
    var rad = this.Length();
    this.v[0] = this.v[0] / rad;
    this.v[1] = this.v[1] / rad;
    this.v[2] = this.v[2] / rad;
    return this;
  }

  this.Negate = function () {
    this.v[0] = -this.v[0];
    this.v[1] = -this.v[1];
    this.v[2] = -this.v[2];
    return this;
  }
  
  this.DotP = function (v2) {
    // cos(theta)
    var cost = (this.v[0] * v2.v[0]) + (this.v[1] * v2.v[1]) + (this.v[2] * v2.v[2]);
    return cost;
  }

  this.CrossP = function (v2) {
    var x = (this.v[1] * v2.v[2]) - (v2.v[1] * this.v[2]);
    var y = (this.v[2] * v2.v[0]) - (v2.v[2] * this.v[0]);
    var z = (this.v[0] * v2.v[1]) - (v2.v[0] * this.v[1]);

    //this.v = [x, y, z, 1];
    //return this;
    var cross = new Vector4().Set3(x, y, z);
    return cross;
  }

  this.Add = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] + v2.v[0]),
      (this.v[1] + v2.v[1]),
      (this.v[2] + v2.v[2]));        
    return add;
  }

  this.Sub = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] - v2.v[0]),
      (this.v[1] - v2.v[1]),
      (this.v[2] - v2.v[2]));        
    return add;
  }

  this.Scale = function (s) {
    var scale = new Vector4().Set3(this.v[0]*s, this.v[1]*s, this.v[2]*s);
    return scale;
  }

  this.Transform = function(b) {
    var dst = new Vector4().Set4(
      ((this.v[0] * b.m[0][0]) + (this.v[1] * b.m[1][0]) + (this.v[2] * b.m[2][0]) + (this.v[3] * b.m[3][0])),
      ((this.v[0] * b.m[0][1]) + (this.v[1] * b.m[1][1]) + (this.v[2] * b.m[2][1]) + (this.v[3] * b.m[3][1])),
      ((this.v[0] * b.m[0][2]) + (this.v[1] * b.m[1][2]) + (this.v[2] * b.m[2][2]) + (this.v[3] * b.m[3][2])),
      ((this.v[0] * b.m[0][3]) + (this.v[1] * b.m[1][3]) + (this.v[2] * b.m[2][3]) + (this.v[3] * b.m[3][3]))
    );
    return dst;
  }

  this.ToString = function () {
    var s = this.v[0].toPrecision(3) + ',' + this.v[1].toPrecision(3) + ',' + this.v[2].toPrecision(3);
    return s;
  }
}