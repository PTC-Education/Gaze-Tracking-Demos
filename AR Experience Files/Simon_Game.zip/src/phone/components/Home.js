// Initialize variables for indexing
$scope.cellOrder = new Array(99); // An array in which the button order is stored
$scope.i=0; // Keeps track of how many times the buttons have been highlighted
$scope.j=0; // Keeps track of which round the user is in
$scope.k=0; // Keeps track of how many times the user has provided input
$scope.speed=500; // Sets the initial game speed
$scope.app.params.roundNumber = 0; // Sets round to zero
$scope.instructionNumber = 0; // For initial popup instructions

// Define button colors
$scope.origGreen = 'rgba(28,214,113,1)';
$scope.origRed = 'rgba(246,71,44,1)';
$scope.origBlue = 'rgba(34,156,221,1)';
$scope.origYellow = 'rgba(239,216,42,1)';
$scope.selectGreen = 'rgba(164,238,198,1)';
$scope.selectRed = 'rgba(252,199,198,1)';
$scope.selectBlue = 'rgba(188,225,244,1)';
$scope.selectYellow = 'rgba(250,243,191,1)';
$scope.highlightColor = 'rgba(255,255,255,1)';

//This function is triggered when the start button is clicked
$scope.firstSquare = function() {
  $scope.setWidgetProp('button-1', 'disabled', true); // Disables start button
  $scope.setWidgetProp('button-2', 'disabled', true); // Disables input button
  $scope.cellOrder[0] = rand(4); // Assigns a random integer (1-4) to the first position of the array
  playMemory(); // Triggers the function that highlights the buttons
}

function playMemory() {
  $scope.state = 'playMemory'; // Defines the game state
  $scope.app.params.roundNumber = $scope.j+1; // Increments the on-screen counter
  if ($scope.i <= $scope.j) {
    switch ($scope.cellOrder[$scope.i]){
      case 1:
        $scope.setWidgetProp('modelItem-1', 'color',  $scope.highlightColor);
        $scope.app.fn.triggerWidgetService('audio-1','play');
        break
      case 2:
        $scope.setWidgetProp('modelItem-2', 'color',  $scope.highlightColor);
        $scope.app.fn.triggerWidgetService('audio-2','play');
        break
      case 3:
        $scope.setWidgetProp('modelItem-3', 'color',  $scope.highlightColor);
        $scope.app.fn.triggerWidgetService('audio-3','play');
        break
      case 4:
        $scope.setWidgetProp('modelItem-4', 'color',  $scope.highlightColor);
        $scope.app.fn.triggerWidgetService('audio-4','play');
        break
    }
    $timeout(function() {nextSquare();}, $scope.speed*2);
  }
  else if ($scope.i > $scope.j){
    nextRound();
  }
}

function nextSquare() {
  $scope.state = 'nextSquare'; // Defines the game state
  $scope.i++;
  clearSquares(); // Resets highlights
  $timeout(function() {playMemory();}, $scope.speed);
}

function nextRound() {
  $scope.state = 'nextRound'; // Defines the game state
  $scope.i=0;
  $scope.k=0;
  $scope.j++;
  $scope.cellOrder[$scope.j] = rand(4); // Assigns a random integer (1-4) to the next position of the array
  $scope.speed = $scope.speed-(100/$scope.j) // Increases the game's speed
  if ($scope.view.wdg['button-2']['text'] == 'Gaze'){gazeInput();} // Triggers the function to use the gaze vector for button selection
}

// Analyzes user input and makes decisions about if it was right or wrong
function yourTurn(cellNumber) {
  $scope.setWidgetProp('image-2', 'imgsrc', 'app/resources/Uploaded/Screen Center.png');
   switch (cellNumber){
      case 1:
       $scope.setWidgetProp('modelItem-1', 'color',  $scope.highlightColor);
       $scope.app.fn.triggerWidgetService('audio-1','play');
       break
      case 2:
       $scope.setWidgetProp('modelItem-2', 'color',  $scope.highlightColor);
       $scope.app.fn.triggerWidgetService('audio-2','play');
       break
      case 3:
       $scope.setWidgetProp('modelItem-3', 'color',  $scope.highlightColor);
       $scope.app.fn.triggerWidgetService('audio-3','play');
       break
      case 4:
       $scope.setWidgetProp('modelItem-4', 'color',  $scope.highlightColor);
       $scope.app.fn.triggerWidgetService('audio-4','play');
       break
    }
    if ($scope.cellOrder[$scope.k] == cellNumber) {
      $scope.k++;
      if ($scope.k == $scope.j) {
        clearInterval($scope.selectButtonByGaze); // Stops the interval function that tracks user gaze input
        $timeout(function() {playMemory();}, 1000);
        }
      else if ($scope.view.wdg['button-2']['text'] == 'Gaze'){
        clearInterval($scope.selectButtonByGaze); // Stops the interval function that tracks user gaze input
        $timeout(function() {gazeInput();}, $scope.speed); // Re-enables gaze selection after a set delay
      }
    $timeout(function() {clearSquares();}, 250); // Resets highlights
  }
  else { // This code runs when the user makes an incorrect selection
    if ($scope.j > 0){
      clearInterval($scope.selectButtonByGaze); // Stops the gaze selection function
      var selectGIF = rand(5);
      switch (selectGIF){ // Randomly selects a GIF to show in the popup window
      case 1:
        $scope.setWidgetProp('image-1', 'imgsrc', 'app/resources/Uploaded/Try Again.gif');
        break
      case 2:
        $scope.setWidgetProp('image-1', 'imgsrc', 'app/resources/Uploaded/Wrong.gif');
        break
      case 3:
        $scope.setWidgetProp('image-1', 'imgsrc', 'app/resources/Uploaded/False.gif');
        break
      case 4:
        $scope.setWidgetProp('image-1', 'imgsrc', 'app/resources/Uploaded/You are Gravely Mistaken.gif');
        break
      case 5:
        $scope.setWidgetProp('image-1', 'imgsrc', 'app/resources/Uploaded/Parks and Rec.gif');
        break
    }
      $scope.setWidgetProp('popup-1', 'visible', true); // Shows the GIF popup
    }
  }
}

// This function resets the color of all the buttons after one was highlighted
function clearSquares() {
	$scope.setWidgetProp('modelItem-1', 'color',  $scope.origGreen);
    $scope.setWidgetProp('modelItem-2', 'color',  $scope.origRed);
    $scope.setWidgetProp('modelItem-3', 'color',  $scope.origBlue);
    $scope.setWidgetProp('modelItem-4', 'color',  $scope.origYellow);
}

// This function allows using gaze to select the buttons
function gazeInput() {
  $scope.timingInterval = 100; // milliseconds
  $scope.buttonSelected = 0; // For tentative selection of buttons
  $scope.timeSelected = 0; // For tentative selection timer
   
  // The code below is for processing location information at a set interval
  $scope.selectButtonByGaze = setInterval(startGazeTracking, $scope.timingInterval);
}

// This function repeats at a set interval and is what processes the user's gaze data
function startGazeTracking() {
  var focusThreshold = 0.995; // For dot product
  var totalSelectTime = 0.55; // Total seconds a button must be selected in order for it to be pressed
  
  $scope.$apply(function(){
    // Creates an array with the dot product values for all objects in the experience
    var focusArray = [$scope.focusGreen, $scope.focusRed, $scope.focusBlue, $scope.focusYellow];
    var maxIndex = $scope.indexOfMax(focusArray); // Calls function to find the index of the array's maximum value
    
    if ($scope.buttonSelected == maxIndex && focusArray[maxIndex] >= focusThreshold) { 
      $scope.timeSelected += ($scope.timingInterval / 1000); // Increments button selected timer;
      $scope.setWidgetProp('image-2', 'imgsrc', 'app/resources/Uploaded/Select Progress.gif');
      switch (maxIndex){
      case 0:
       $scope.setWidgetProp('modelItem-1', 'color',  $scope.selectGreen);
       break
      case 1:
       $scope.setWidgetProp('modelItem-2', 'color',  $scope.selectRed);
       break
      case 2:
       $scope.setWidgetProp('modelItem-3', 'color',  $scope.selectBlue);
       break
      case 3:
       $scope.setWidgetProp('modelItem-4', 'color',  $scope.selectYellow);
       break
    }
    }
    else { // If the user looks away from the button currently selected
      $scope.buttonSelected = maxIndex;
      $scope.timeSelected = 0; // Reset the button timer
      clearSquares();
      $scope.setWidgetProp('image-2', 'imgsrc', 'app/resources/Uploaded/Screen Center.png');
    }
    
    // These if/else statements determine which object the user is looking at using their focus
    if (focusArray[maxIndex] >= focusThreshold && $scope.timeSelected >= totalSelectTime) {
      yourTurn(maxIndex+1);
    }
  });      
}

// This function resets the game so it can be played again
$scope.restartGame = function() {
  $scope.state = 'Start';
  $scope.i=0;
  $scope.j=0;
  $scope.k=0;
  $scope.speed=500;
  $scope.app.params.roundNumber = 0;
  $scope.setWidgetProp('popup-1', 'visible', false); // Hides popup
  $scope.setWidgetProp('button-1', 'disabled', false); // Enables start button
  $scope.setWidgetProp('button-2', 'disabled', false); // Enables input button
  clearSquares();
}

// The following functions are triggered when one of the buttons are clicked
$scope.clickButton = function(buttonNumber) {
  if ($scope.state == 'nextRound' && $scope.view.wdg['button-2']['text'] == 'Touch') {
    yourTurn(buttonNumber); // 1=Green, 2=Red, 3=Blue, 4=Yellow
  }
}

// This function is triggered when the Gaze/Touch button is clicked
$scope.inputButton = function() {
 if ($scope.view.wdg['button-2']['text'] == 'Gaze') {
   $scope.setWidgetProp('button-2', 'text', 'Touch');
   $scope.setWidgetProp('button-2', 'class', 'ptc-button2');
   $scope.setWidgetProp('image-2', 'visible', false);
 }
  else if ($scope.view.wdg['button-2']['text'] == 'Touch') {
   $scope.setWidgetProp('button-2', 'text', 'Gaze');
    $scope.setWidgetProp('button-2', 'class', 'ptc-button');
    $scope.setWidgetProp('image-2', 'visible', true);
 }
}

// Gets the index of the element with the highest value. This tells us which object is closest to the center of the screen.
$scope.indexOfMax = function(arr) {
  var max = arr[0];
  var maxIndex = 0;
  
  // Indexes through all array elements and records the index of the element with the highest value.
  for (var i = 1; i < arr.length; i++) {
    if (arr[i] > max) {
      maxIndex = i;
      max = arr[i];
    }
  }
  return maxIndex;
}

// Changes the in the instructional popup
$scope.nextInstruction = function() {
  switch ($scope.instructionNumber){
    case 0:
      $scope.setWidgetProp('label-2', 'text',  'Game Overview');
      $scope.setWidgetProp('label-3', 'text',  'The challenge is to repeat the ever-increasing sequence of signals.');
      $scope.setWidgetProp('label-4', 'text',  'Do you have the memory and reflexes to beat Simon?');
      $scope.setWidgetProp('label-4', 'class',  'ptc-body-label');
      $scope.instructionNumber++;
      break
    case 1:
      $scope.setWidgetProp('label-2', 'text',  'How To Play');
      $scope.setWidgetProp('label-3', 'text',  '1. Press the "Start" button to begin the game.');
      $scope.setWidgetProp('label-4', 'text',  '2. Simon will give the first signal. (One of the buttons will light up, accompanied by a tone.)');
      $scope.instructionNumber++;
      break
    case 2:
      $scope.setWidgetProp('label-3', 'text',  '3. Repeat that signal by touching the same button.');
      $scope.setWidgetProp('label-4', 'text',  '4. Simon will repeat the first signal and then add one more.');
      $scope.setWidgetProp('label-5', 'text',  '5. Repeat those two signals in the same order.');
      $scope.instructionNumber++;
      break
    case 3:
      $scope.setWidgetProp('label-3', 'text',  '6. Simon will continue to play the sequence and add one. Continue to repeat Simon for as long as you can!');
      $scope.setWidgetProp('label-4', 'text',  '');
      $scope.setWidgetProp('label-5', 'text',  '');
      $scope.instructionNumber++;
      break
    case 4:
      $scope.setWidgetProp('label-2', 'text',  'Input Methods');
      $scope.setWidgetProp('label-3', 'text',  'You can play the game either by pointing your device at the button you want to select or by tapping on the button on your screen.');
      $scope.setWidgetProp('label-4', 'text',  '(Switch to between modes by toggling the button in the lower-right corner.)');
      $scope.setWidgetProp('label-4', 'class',  'ptc-body-italic-label')
      $scope.setWidgetProp('button-3', 'text',  'Close');
      $scope.instructionNumber++;
      break
    case 5: // Reset labels back to initial instruction state
      $scope.app.fn.triggerWidgetService('popup-2','hidepopup');
      $scope.setWidgetProp('label-2', 'text',  'Welcome to Simon in AR!');
      $scope.setWidgetProp('label-3', 'text',  'Please use this guide to learn how to play this unique and entertaining game:');
      $scope.setWidgetProp('label-4', 'text',  'Skip');
      $scope.setWidgetProp('label-4', 'class',  'ptc-skip-label');
      $scope.setWidgetProp('button-3', 'text',  'Next');
      $scope.instructionNumber = 0;
      
  }
}

// Hides the instructional popup if 'Skip' is pressed, but only when the popup is on the welcome instruction
$scope.skipInstructions = function() {if($scope.instructionNumber == 0) {$scope.app.fn.triggerWidgetService('popup-2','hidepopup');}}

// The Central Randomizer 1.3 (C) 1997 by Paul Houle (houle@msc.cornell.edu)
// See:  http://www.msc.cornell.edu/~houle/javascript/randomizer.html

rnd.today=new Date();
rnd.seed=rnd.today.getTime();
function rnd() {
  rnd.seed = (rnd.seed*9301+49297) % 233280;
  return rnd.seed/(233280.0);
}
function rand(number) {
  return Math.ceil(rnd()*number);
}
// end central randomizer.

// This code is adapted from 'Sort of Simon' -- Game written and developed by Peter A. Zink (http://pzink.com)
// Based on 'https://en.wikipedia.org/wiki/Simon_(game)' the classic Milton-Bradley game
// Uses the Central Randomizer 1.3 (C) 1997 by Paul Houle, http://www.msc.cornell.edu/~houle/javascript/randomizer.html

/*
A look into how to use the tacking even for features such as gaze tracking
BE SURE TO ENABLE TRACKING EVENTS IN '3D CONTAINER'
*/

/*
Firstly, the 'tracking' event. This is called from the core viewer, and it passed the following three elements that make up the viewpoint of the viewer.

arg.position = vector(3) xyz positional offset from the root tracker
arg.gaze = vector(3) defining the direction of the head - think of this as an arrow pointing from the center of the head/camera out through the eyes 
arg.up = vector(3) defining the up direction - think of this as an arrow from the center of the head/camera pointing up through the head

As the device moves, these values change and this event is fired

The up and gaze vectors should already be normalized meaning that are unit vectors (length = 1). it is important during vector/matrix maths to keep certain vectors normalised.

It is VERY IMPORTANT not to spend too long in this function as it is a callback from the main render thread. Instead, collect the values and perhaps use an interval timer or $timeout to complete any functionality. 
*/

// This function watches for every time the experience 'tracking' event is fired and executes each time
$scope.$on('tracking', function(evt, arg) {
  // Let's start by extracting the values into some helper objects
  var headpos  = new Vector4().Set3a(arg.position);	// Position as a vector
  var headgaze = new Vector4().Set3a(arg.gaze); // Gaze as a vector
  var headup   = new Vector4().Set3a(arg.up);
  
  
  // The code below is for determining the user's focus on and distance to the green button
  var gazeGreen = new Vector4().Set3(($scope.view.wdg['modelItem-1']['x'] + $scope.view.wdg['model-1']['x'] - arg.position[0]),($scope.view.wdg['modelItem-1']['y'] + $scope.view.wdg['model-1']['y'] - arg.position[1]),($scope.view.wdg['modelItem-1']['z'] + $scope.view.wdg['model-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the green button's coordinates
  var gazeGreenNorm = gazeGreen.Normalize(); // Normalizes the vector for the dot product
  $scope.focusGreen = headgaze.DotP(gazeGreenNorm); // Takes the dot product of the vector to green button and user's gaze vector

  // The code below is for determining the user's focus on and distance to the red button
  var gazeRed = new Vector4().Set3(($scope.view.wdg['modelItem-2']['x'] + $scope.view.wdg['model-1']['x'] - arg.position[0]),($scope.view.wdg['modelItem-2']['y'] + $scope.view.wdg['model-1']['y'] - arg.position[1]),($scope.view.wdg['modelItem-2']['z'] + $scope.view.wdg['model-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the red button's coordinates
  var gazeRedNorm = gazeRed.Normalize(); // Normalizes the vector for the dot product
  $scope.focusRed = headgaze.DotP(gazeRedNorm); // Takes the dot product of the vector to red button and user's gaze vector
  
  // The code below is for determining the user's focus on and distance to the blue button
  var gazeBlue = new Vector4().Set3(($scope.view.wdg['modelItem-3']['x'] + $scope.view.wdg['model-1']['x'] - arg.position[0]),($scope.view.wdg['modelItem-3']['y'] + $scope.view.wdg['model-1']['y'] - arg.position[1]),($scope.view.wdg['modelItem-3']['z'] + $scope.view.wdg['model-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the blue button's coordinates
  var gazeBlueNorm = gazeBlue.Normalize(); // Normalizes the vector for the dot product
  $scope.focusBlue = headgaze.DotP(gazeBlueNorm); // Takes the dot product of the vector to blue button and user's gaze vector
 
  // The code below is for determining the user's focus on and distance to the yellow button
  var gazeYellow = new Vector4().Set3(($scope.view.wdg['modelItem-4']['x'] + $scope.view.wdg['model-1']['x'] - arg.position[0]),($scope.view.wdg['modelItem-4']['y'] + $scope.view.wdg['model-1']['y'] - arg.position[1]),($scope.view.wdg['modelItem-4']['z'] + $scope.view.wdg['model-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the yellow button's coordinates
  var gazeYellowNorm = gazeYellow.Normalize(); // Normalizes the vector for the dot product
  $scope.focusYellow = headgaze.DotP(gazeYellowNorm); // Takes the dot product of the vector to yellow button and user's gaze vector
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Steve's simple matrix/vector library
function Vector4() {
  this.v = [0, 0, 0, 1];

  this.X = function() { return this.v[0] }
  this.Y = function() { return this.v[1] }
  this.Z = function() { return this.v[2] }
  this.W = function() { return this.v[3] }

  this.Set3 = function (x, y, z) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    return this;
  }

  this.Set3a = function (a) {
    this.v[0] = a[0];
    this.v[1] = a[1];
    this.v[2] = a[2];
    return this;
  }

  this.Set4 = function (x, y, z, w) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    this.v[3] = w;
    return this;
  }

  this.SetV4 = function (v) {
    this.v[0] = v.v[0];
    this.v[1] = v.v[1];
    this.v[2] = v.v[2];
    this.v[3] = v.v[3];
    return this;
  }

  this.Length = function () {
    var hyp = (this.v[0] * this.v[0]) + (this.v[1] * this.v[1]) + (this.v[2] * this.v[2]);
    var rad = (hyp > 0) ? Math.sqrt(hyp) : 0;
    return rad;
  }

  this.Normalize = function () {
    var rad = this.Length();
    this.v[0] = this.v[0] / rad;
    this.v[1] = this.v[1] / rad;
    this.v[2] = this.v[2] / rad;
    return this;
  }

  this.DotP = function (v2) {
    // cos(theta)
    var cost = (this.v[0] * v2.v[0]) + (this.v[1] * v2.v[1]) + (this.v[2] * v2.v[2]);
    return cost;
  }
}
