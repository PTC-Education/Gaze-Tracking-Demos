// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

$scope.startLogging = function() {
  var startParameters = {'Xcoordinate': 'N/A', 'Ycoordinate': 'N/A', 'Zcoordinate': 'N/A', 'timestamp': Date.now(), 'userID': $scope.app.params.userID}
     twx.app.fn.triggerDataService("JF_GazeTracking_Test", "getTracking", startParameters);
}