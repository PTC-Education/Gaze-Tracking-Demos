// This function is triggered when tracking is established
$scope.$on('trackingacquired',function() {
  var timingInterval = 10; // milliseconds
  
  // The code below is for processing data at a set interval
  $scope.getGazeTracking = setInterval(function() {   
    $scope.$apply(function(){ 
      // This code is optional and used when you want to log gaze tracking data in ThingWorx
      /*var TWXthingID = 'JF_GazeTracking_Test'; // The name of your 'Thing' in ThingWorx
      var serviceName = 'getTracking'; // The name of the ThingWorx service your are executing
      var serviceParameters = {'Xcoordinate': $scope.coordX, 'Ycoordinate': $scope.coordY, 'Zcoordinate': $scope.coordZ, 'timestamp': Date.now()} // Contains the JSON data for the service inputs
     
      twx.app.fn.triggerDataService(TWXthingID, serviceName, serviceParameters);*/
     
      // Sets the model coordinates to mirror the user's position across the Z-plane
      $scope.setWidgetProp('model-1', 'x', $scope.coordX);
      $scope.setWidgetProp('model-1', 'y', $scope.coordY);
      $scope.setWidgetProp('model-1', 'z', -$scope.coordZ);
                
      // Updates the labels on the left side of the screen to display the user's coordinates
      $scope.setWidgetProp('label-2', 'text', $scope.coordX);
      $scope.setWidgetProp('label-4', 'text', $scope.coordY);
      $scope.setWidgetProp('label-6', 'text', $scope.coordZ);
            
      // Updates the labels on the left side of the screen to display the X,Y,Z components of the user's gaze vector
      $scope.setWidgetProp('label-8', 'text', $scope.rotX1);
      $scope.setWidgetProp('label-10', 'text', $scope.rotY1);
      $scope.setWidgetProp('label-12', 'text', $scope.rotZ1);
    });  
  }, timingInterval);
})

// This function is triggered when tracking is lost
$scope.$on('trackinglost',function() {
  clearInterval($scope.getGazeTracking);  // Stops the interval function that mirrors the model's position
  
  // Sets all labels to 'Tracking Lost'
  $scope.setWidgetProp('label-2', 'text', 'Tracking Lost');
  $scope.setWidgetProp('label-4', 'text', 'Tracking Lost');
  $scope.setWidgetProp('label-6', 'text', 'Tracking Lost');
  $scope.setWidgetProp('label-8', 'text', 'Tracking Lost');
  $scope.setWidgetProp('label-10', 'text', 'Tracking Lost');
  $scope.setWidgetProp('label-12', 'text', 'Tracking Lost');
})

/*
A look into how to use the tacking even for features such as gaze tracking
BE SURE TO ENABLE TRACKING EVENTS IN '3D CONTAINER'
*/

/*
Firstly, the 'tracking' event. This is called from the core viewer, and it passed the following three elements that make up the viewpoint of the viewer.

arg.position = vector(3) xyz positional offset from the root tracker
arg.gaze = vector(3) defining the direction of the head - think of this as an arrow pointing from the center of the head/camera out through the eyes 
arg.up = vector(3) defining the up direction - think of this as an arrow from the center of the head/camera pointing up through the head

As the device moves, these values change and this event is fired

The up and gaze vectors should already be normalized meaning that are unit vectors (length =1). it is important during vector/matrix maths to keep certain vectors normalised.

It is VERY IMPORTANT not to spend too long in this function as it is a callback from the main render thread. Instead, collect the values and perhaps use an interval timer or $timeout to complete any functionality. 
*/

// This function watches for every time the experience 'tracking' event is fired and executes each time
$scope.$on('tracking', function(evt, arg) {
  
  // Let's start by extracting the values into some helper objects
  var headpos  = new Vector4().Set3a(arg.position);	// Position as a vector
  var headgaze = new Vector4().Set3a(arg.gaze); // Gaze as a vector
  var headup   = new Vector4().Set3a(arg.up); 
  
  // Defines variables containing the user's coordinates, gaze vector, and headup vector
  $scope.coordX = arg.position[0].toPrecision(4);
  $scope.coordY = arg.position[1].toPrecision(4);
  $scope.coordZ = arg.position[2].toPrecision(4);
  
  $scope.rotX1 = arg.gaze[0].toPrecision(4);
  $scope.rotY1 = arg.gaze[1].toPrecision(4);
  $scope.rotZ1 = arg.gaze[2].toPrecision(4);
  
  $scope.rotX2 = arg.up[0].toPrecision(4);
  $scope.rotY2 = arg.up[1].toPrecision(4);
  $scope.rotZ2 = arg.up[2].toPrecision(4);  
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Steve's simple matrix/vector library
function Matrix4() {
  this.m = [ [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]];

  this.Set3V = function(v1,v2,v3) {
    this.m[0][0] = v1.v[0];
    this.m[0][1] = v1.v[1];
    this.m[0][2] = v1.v[2];

    this.m[1][0] = v2.v[0];
    this.m[1][1] = v2.v[1];
    this.m[1][2] = v2.v[2];

    this.m[2][0] = v3.v[0];
    this.m[2][1] = v3.v[1];
    this.m[2][2] = v3.v[2];
    return this;
  }
  this.Set4V = function(v1,v2,v3,v4) {
    this.m[0][0] = v1.v[0];
    this.m[0][1] = v1.v[1];
    this.m[0][2] = v1.v[2];
    this.m[1][0] = v2.v[0];
    this.m[1][1] = v2.v[1];
    this.m[1][2] = v2.v[2];
    this.m[2][0] = v3.v[0];
    this.m[2][1] = v3.v[1];
    this.m[2][2] = v3.v[2];
    this.m[3][0] = v4.v[0];
    this.m[3][1] = v4.v[1];
    this.m[3][2] = v4.v[2];
    return this;
  }

  this.Translate = function (x, y, z) {
    var t = [ [1, 0, 0, 0],
             [0, 1, 0, 0],
             [0, 0, 1, 0],
             [x, y, z, 1]];
    return this.Multiply(t);
  }

  this.TranslateV4 = function (v) {  // takes a Vector4
    var t = [ [1, 0, 0, 0],
              [0, 1, 0, 0],
              [0, 0, 1, 0],
              [v.v[0], v.v[1], v.v[2], 1]];
    return this.Multiply(t);
  }

  this.Scale = function (x, y, z) {
    var s = [ [x, 0, 0, 0],
             [0, y, 0, 0],
             [0, 0, z, 0],
             [0, 0, 0, 1]];
    return this.Multiply(s);
  }

  this.Rotate = function (axis, angle) {
    var s  = Math.sin(angle);
    var c0 = Math.cos(angle);
    var c1 = 1 - c0;

    // assume normalised input vector
    var u = axis[0];
    var v = axis[1];
    var w = axis[2];

    var r = [
      [(u * u * c1) + c0,      (u * v * c1) - (w * s), (u * w * c1) + (v * s), 0],
      [(u * v * c1) + (w * s), (v * v * c1) + c0,      (v * w * c1) - (u * s), 0],
      [(u * w * c1) - (v * s), (v * w * c1) + (u * s), (w * w * c1) + c0,      0],
      [0,                      0,                      0,                      1]
    ];


    return this.Multiply(r);
  }

  this.Multiply = function (b) {
    var dst = [ 
      [   ((this.m[0][0] * b[0][0]) + (this.m[0][1] * b[1][0]) + (this.m[0][2] * b[2][0]) + (this.m[0][3] * b[3][0])),
       ((this.m[0][0] * b[0][1]) + (this.m[0][1] * b[1][1]) + (this.m[0][2] * b[2][1]) + (this.m[0][3] * b[3][1])),
       ((this.m[0][0] * b[0][2]) + (this.m[0][1] * b[1][2]) + (this.m[0][2] * b[2][2]) + (this.m[0][3] * b[3][2])),
       ((this.m[0][0] * b[0][3]) + (this.m[0][1] * b[1][3]) + (this.m[0][2] * b[2][3]) + (this.m[0][3] * b[3][3])) ],
      [   ((this.m[1][0] * b[0][0]) + (this.m[1][1] * b[1][0]) + (this.m[1][2] * b[2][0]) + (this.m[1][3] * b[3][0])),
       ((this.m[1][0] * b[0][1]) + (this.m[1][1] * b[1][1]) + (this.m[1][2] * b[2][1]) + (this.m[1][3] * b[3][1])),
       ((this.m[1][0] * b[0][2]) + (this.m[1][1] * b[1][2]) + (this.m[1][2] * b[2][2]) + (this.m[1][3] * b[3][2])),
       ((this.m[1][0] * b[0][3]) + (this.m[1][1] * b[1][3]) + (this.m[1][2] * b[2][3]) + (this.m[1][3] * b[3][3])) ],
      [   ((this.m[2][0] * b[0][0]) + (this.m[2][1] * b[1][0]) + (this.m[2][2] * b[2][0]) + (this.m[2][3] * b[3][0])),
       ((this.m[2][0] * b[0][1]) + (this.m[2][1] * b[1][1]) + (this.m[2][2] * b[2][1]) + (this.m[2][3] * b[3][1])),
       ((this.m[2][0] * b[0][2]) + (this.m[2][1] * b[1][2]) + (this.m[2][2] * b[2][2]) + (this.m[2][3] * b[3][2])),
       ((this.m[2][0] * b[0][3]) + (this.m[2][1] * b[1][3]) + (this.m[2][2] * b[2][3]) + (this.m[2][3] * b[3][3])) ],
      [   ((this.m[3][0] * b[0][0]) + (this.m[3][1] * b[1][0]) + (this.m[3][2] * b[2][0]) + (this.m[3][3] * b[3][0])),
       ((this.m[3][0] * b[0][1]) + (this.m[3][1] * b[1][1]) + (this.m[3][2] * b[2][1]) + (this.m[3][3] * b[3][1])),
       ((this.m[3][0] * b[0][2]) + (this.m[3][1] * b[1][2]) + (this.m[3][2] * b[2][2]) + (this.m[3][3] * b[3][2])),
       ((this.m[3][0] * b[0][3]) + (this.m[3][1] * b[1][3]) + (this.m[3][2] * b[2][3]) + (this.m[3][3] * b[3][3])) ]];
    this.m = dst;
    return this;
  }

  this.makeOrtho = function(left, right, bottom, top, znear, zfar) {
    var X = -(right + left) / (right - left);
    var Y = -(top + bottom) / (top - bottom);
    var Z = -(zfar + znear) / (zfar - znear);
    var A = 2 / (right - left);
    var B = 2 / (top - bottom);
    var C = -2 / (zfar - znear);

    this.m = [[A, 0, 0, 0],
              [0, B, 0, 0],
              [0, 0, C, 0],
              [X, Y, Z, 1]];
    return this;
  }

  this.makePerspective = function(fovy, aspect, znear, zfar) {
    var ymax = znear * Math.tan(fovy * Math.PI / 360.0);
    var ymin = -ymax;
    var xmin = ymin * aspect;
    var xmax = ymax * aspect;

    this.makeFrustum(xmin, xmax, ymin, ymax, znear, zfar);
    return this;
  }

  this.makeFrustum = function(left, right, bottom, top, znear, zfar) {
    var X = 2 * znear / (right - left);
    var Y = 2 * znear / (top - bottom);
    var A = (right + left) / (right - left);
    var B = (top + bottom) / (top - bottom);
    var C = -(zfar + znear) / (zfar - znear);
    var D = -2 * zfar * znear / (zfar - znear);

    this.m = [[X, 0, 0, 0],
              [0, Y, 0, 0],
              [A, B, C, -1],
              [0, 0, D, 1]];
    return this;
  }
  
  this.makeLookat = function(at,from,up) {
    var lookv  = at.Sub(from).Normalize();
    var xd     = up.Normalize().CrossP(lookv.Normalize());
    var nup    = lookv.CrossP(xd).Normalize(); // recalc up
    var lookat = new Matrix4().Set4V(xd,nup,lookv,from);
    return lookat;
  }
    
  this.makePose = function(at,gaze,up) {
    var xd   = up.Normalize().CrossP(gaze.Normalize());
    var nup  = gaze.CrossP(xd).Normalize(); // recalc up
    var pose = new Matrix4().Set4V(xd,nup,gaze,at);
    return pose;
  }
  
  this.Flatten = function () {
    var f = [];
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < 4 ; j++) {
        f.push(this.m[i][j]);
      }
    }
    return f;
  }

  this.ToString = function () {
    var s = '';
    for (var i = 0; i < 4; i++) {
      s = s.concat(this.m[i].toString());
      s = s.concat(',');
    }
    // now replace the commas with spaces
    s = s.replace(/,/g, ' ');
    return s;
  }

  this.ToEuler = function(toDeg) {
    
        // assumes the upper 3x3 of m is a pure rotation matrix (i.e, unscaled)
        var m11 = this.m[0][0], m12 = this.m[1][0], m13 = this.m[2][0];
        var m21 = this.m[0][1], m22 = this.m[1][1], m23 = this.m[2][1];
        var m31 = this.m[0][2], m32 = this.m[1][2], m33 = this.m[2][2];
        var sy = Math.sqrt(m32 * m32 + m33 * m33);
     
        var singular = (sy < 0.000001) ? true : false;
        var _x, _y, _z;
        
        if (singular === false) {
            _x = Math.atan2(  m32, m33);
            _y = Math.atan2(- m31, sy);
            _z = Math.atan2(  m21, m11);
        } else {
            _x = Math.atan2(- m32, m22);
            _y = Math.atan2(- m31, sy);
            _z = 0;
        }
        
        // convert to degrees?
        var deg = (toDeg != undefined) ? 180.0/Math.PI : 1; 
        var attitude = deg * _x; // make this left handed
        var heading  = deg * _y;
        var bank     = deg * _z;
        
        return { 
          attitude:attitude, 
          heading :heading, 
          bank    :bank 
        };
  }
  
  this.ToPosEuler = function(toDeg) {
    var clamp = function(x) {
      if (Math.abs(x) < 1e-6)
        return 0;
      else 
        return x;
    }

    var rot = this.ToEuler(toDeg);
        
    var simple = {};
    simple.pos = new Vector4().Set3(clamp(this.m[3][0]), clamp(this.m[3][1]), clamp(this.m[3][2]));
    simple.rot = new Vector4().Set3(rot.attitude, rot.heading, rot.bank);
    return simple;
  }

}

// quick way to do perspective matrices
function MatrixP() { }
MatrixP.prototype = new Matrix4()
function MatrixP(fovy, aspect, znear, zfar) {
    this.makePerspective(fovy, aspect, znear, zfar);
}

// quick way to do orthographic matrices
function MatrixO() { }
MatrixO.prototype = new Matrix4()
function MatrixO(left, right, bottom, top, znear, zfar) {
    this.makeOrtho(left, right, bottom, top, znear, zfar);
}


function Vector4() {
  this.v = [0, 0, 0, 1];

  this.X = function() { return this.v[0] }
  this.Y = function() { return this.v[1] }
  this.Z = function() { return this.v[2] }
  this.W = function() { return this.v[3] }

  this.Set3 = function (x, y, z) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    return this;
  }

  this.Set3a = function (a) {
    this.v[0] = a[0];
    this.v[1] = a[1];
    this.v[2] = a[2];
    return this;
  }

  this.Set4 = function (x, y, z, w) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    this.v[3] = w;
    return this;
  }

  this.SetV4 = function (v) {
    this.v[0] = v.v[0];
    this.v[1] = v.v[1];
    this.v[2] = v.v[2];
    this.v[3] = v.v[3];
    return this;
  }

  this.Length = function () {
    var hyp = (this.v[0] * this.v[0]) + (this.v[1] * this.v[1]) + (this.v[2] * this.v[2]);
    var rad = (hyp > 0) ? Math.sqrt(hyp) : 0;
    return rad;
  }

  this.Normalize = function () {
    var rad = this.Length();
    this.v[0] = this.v[0] / rad;
    this.v[1] = this.v[1] / rad;
    this.v[2] = this.v[2] / rad;
    return this;
  }

  this.Negate = function () {
    this.v[0] = -this.v[0];
    this.v[1] = -this.v[1];
    this.v[2] = -this.v[2];
    return this;
  }

  this.DotP = function (v2) {
    // cos(theta)
    var cost = (this.v[0] * v2.v[0]) + (this.v[1] * v2.v[1]) + (this.v[2] * v2.v[2]);
    return cost;
  }

  this.CrossP = function (v2) {
    var x = (this.v[1] * v2.v[2]) - (v2.v[1] * this.v[2]);
    var y = (this.v[2] * v2.v[0]) - (v2.v[2] * this.v[0]);
    var z = (this.v[0] * v2.v[1]) - (v2.v[0] * this.v[1]);

    //this.v = [x, y, z, 1];
    //return this;
    var cross = new Vector4().Set3(x, y, z);
    return cross;
  }

  this.Add = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] + v2.v[0]),
      (this.v[1] + v2.v[1]),
      (this.v[2] + v2.v[2]));        
    return add;
  }

  this.Sub = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] - v2.v[0]),
      (this.v[1] - v2.v[1]),
      (this.v[2] - v2.v[2]));        
    return add;
  }

  this.Scale = function (s) {
    var scale = new Vector4().Set3(this.v[0]*s, this.v[1]*s, this.v[2]*s);
    return scale;
  }

  this.Transform = function(b) {
    var dst = new Vector4().Set4(
      ((this.v[0] * b.m[0][0]) + (this.v[1] * b.m[1][0]) + (this.v[2] * b.m[2][0]) + (this.v[3] * b.m[3][0])),
      ((this.v[0] * b.m[0][1]) + (this.v[1] * b.m[1][1]) + (this.v[2] * b.m[2][1]) + (this.v[3] * b.m[3][1])),
      ((this.v[0] * b.m[0][2]) + (this.v[1] * b.m[1][2]) + (this.v[2] * b.m[2][2]) + (this.v[3] * b.m[3][2])),
      ((this.v[0] * b.m[0][3]) + (this.v[1] * b.m[1][3]) + (this.v[2] * b.m[2][3]) + (this.v[3] * b.m[3][3]))
    );
    return dst;
  }

  this.ToString = function () {
    var s = this.v[0].toPrecision(3) + ',' + this.v[1].toPrecision(3) + ',' + this.v[2].toPrecision(3);
    return s;
  }
}