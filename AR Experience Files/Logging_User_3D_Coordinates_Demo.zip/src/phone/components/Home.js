// This function is triggered when the experience is first opened
$scope.$on('$ionicView.afterEnter',function(array){
  // Initializes all timers
  $scope.experienceTimer = 0; // Duration of experience
})

// This function is triggered when tracking is established
$scope.$on('trackingacquired',function() {
  var timingInterval = 500; // milliseconds
        
  // The code below is for processing data at a set interval
  $scope.getUserCoordinates = setInterval(function() {     
    $scope.$apply(function(){                 
      // This code is optional and used when you want to log gaze tracking data in ThingWorx
      /*var TWXthingID = 'JF_UserCoordLogging_DT'; // The name of your 'Thing' in ThingWorx
      var serviceName = 'getCoordinates'; // The name of the ThingWorx service your are executing 
      // Defining objects to make passing data to ThingWorx much easier
      const userCoord = {
        X: $scope.userX,
        Y: $scope.userY,
        Z: $scope.userZ
      };
      const otherData = {
        experienceTimer: $scope.experienceTimer.toFixed(1),
        model1Focus: $scope.model1Focus,
        model1X: $scope.view.wdg['model-1']['x'].toPrecision(4),
        model1Y: $scope.view.wdg['model-1']['y'].toPrecision(4),
        model1Z: $scope.view.wdg['model-1']['z'].toPrecision(4)
       }      
      
        // Contains the JSON data for the service inputs
      var serviceParameters = {'userCoord': userCoord, 'otherData': otherData};
      
      // Calls a ThingWorx service and inputs all the parameters defined above
      twx.app.fn.triggerDataService(TWXthingID, serviceName, serviceParameters);*/
      
      $scope.experienceTimer += (timingInterval / 1000); // Increments experience timer
    });  
 }, timingInterval);
})

// This function is triggered when tracking is lost
$scope.$on('trackinglost',function() {
  clearInterval($scope.getUserCoordinates); // Stops the interval function that increments the timers
})

/*
A look into how to use the tacking even for features such as gaze tracking
BE SURE TO ENABLE TRACKING EVENTS IN '3D CONTAINER'
*/

/*
Firstly, the 'tracking' event. This is called from the core viewer, and it passed the following three elements that make up the viewpoint of the viewer.

arg.position = vector(3) xyz positional offset from the root tracker
arg.gaze = vector(3) defining the direction of the head - think of this as an arrow pointing from the center of the head/camera out through the eyes 
arg.up = vector(3) defining the up direction - think of this as an arrow from the center of the head/camera pointing up through the head

As the device moves, these values change and this event is fired

The up and gaze vectors should already be normalized meaning that are unit vectors (length = 1). it is important during vector/matrix maths to keep certain vectors normalised.

It is VERY IMPORTANT not to spend too long in this function as it is a callback from the main render thread. Instead, collect the values and perhaps use an interval timer or $timeout to complete any functionality. 
*/

// This function watches for every time the experience 'tracking' event is fired and executes each time
$scope.$on('tracking', function(evt, arg) {
  
  // Let's start by extracting the values into some helper objects
  var headpos  = new Vector4().Set3a(arg.position);	// Position as a vector
  var headgaze = new Vector4().Set3a(arg.gaze); // Gaze as a vector
  var headup   = new Vector4().Set3a(arg.up);
  
  // The code below is for determining the user's focus on and distance to object 1
  var gazeVector1 = new Vector4().Set3(($scope.view.wdg['model-1']['x'] - arg.position[0]),($scope.view.wdg['model-1']['y'] - arg.position[1]),($scope.view.wdg['model-1']['z'] - arg.position[2])); // Defines a vector from the user's coordinates to the model's coordinates
  var gazeVectorNorm1 = gazeVector1.Normalize(); //Normalizes the vector for the dot product
  $scope.model1Focus = headgaze.DotP(gazeVectorNorm1); // Takes the dot product of the vector to model 1 and user's gaze vector

  // Defines variables containing the user's coordinates, gaze vector, and headup vector
  $scope.userX = arg.position[0].toPrecision(4);
  $scope.userY = arg.position[1].toPrecision(4);
  $scope.userZ = arg.position[2].toPrecision(4);  
});



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Steve's simple vector library
function Vector4() {
  this.v = [0, 0, 0, 1];

  this.X = function() { return this.v[0] }
  this.Y = function() { return this.v[1] }
  this.Z = function() { return this.v[2] }
  this.W = function() { return this.v[3] }

  this.Set3 = function (x, y, z) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    return this;
  }

  this.Set3a = function (a) {
    this.v[0] = a[0];
    this.v[1] = a[1];
    this.v[2] = a[2];
    return this;
  }

  this.Set4 = function (x, y, z, w) {
    this.v[0] = x;
    this.v[1] = y;
    this.v[2] = z;
    this.v[3] = w;
    return this;
  }

  this.SetV4 = function (v) {
    this.v[0] = v.v[0];
    this.v[1] = v.v[1];
    this.v[2] = v.v[2];
    this.v[3] = v.v[3];
    return this;
  }

  this.Length = function () {
    var hyp = (this.v[0] * this.v[0]) + (this.v[1] * this.v[1]) + (this.v[2] * this.v[2]);
    var rad = (hyp > 0) ? Math.sqrt(hyp) : 0;
    return rad;
  }

  this.Normalize = function () {
    var rad = this.Length();
    this.v[0] = this.v[0] / rad;
    this.v[1] = this.v[1] / rad;
    this.v[2] = this.v[2] / rad;
    return this;
  }

  this.Negate = function () {
    this.v[0] = -this.v[0];
    this.v[1] = -this.v[1];
    this.v[2] = -this.v[2];
    return this;
  }
  
  this.DotP = function (v2) {
    // cos(theta)
    var cost = (this.v[0] * v2.v[0]) + (this.v[1] * v2.v[1]) + (this.v[2] * v2.v[2]);
    return cost;
  }

  this.CrossP = function (v2) {
    var x = (this.v[1] * v2.v[2]) - (v2.v[1] * this.v[2]);
    var y = (this.v[2] * v2.v[0]) - (v2.v[2] * this.v[0]);
    var z = (this.v[0] * v2.v[1]) - (v2.v[0] * this.v[1]);

    //this.v = [x, y, z, 1];
    //return this;
    var cross = new Vector4().Set3(x, y, z);
    return cross;
  }

  this.Add = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] + v2.v[0]),
      (this.v[1] + v2.v[1]),
      (this.v[2] + v2.v[2]));        
    return add;
  }

  this.Sub = function (v2) {
    var add = new Vector4().Set3(
      (this.v[0] - v2.v[0]),
      (this.v[1] - v2.v[1]),
      (this.v[2] - v2.v[2]));        
    return add;
  }

  this.Scale = function (s) {
    var scale = new Vector4().Set3(this.v[0]*s, this.v[1]*s, this.v[2]*s);
    return scale;
  }

  this.Transform = function(b) {
    var dst = new Vector4().Set4(
      ((this.v[0] * b.m[0][0]) + (this.v[1] * b.m[1][0]) + (this.v[2] * b.m[2][0]) + (this.v[3] * b.m[3][0])),
      ((this.v[0] * b.m[0][1]) + (this.v[1] * b.m[1][1]) + (this.v[2] * b.m[2][1]) + (this.v[3] * b.m[3][1])),
      ((this.v[0] * b.m[0][2]) + (this.v[1] * b.m[1][2]) + (this.v[2] * b.m[2][2]) + (this.v[3] * b.m[3][2])),
      ((this.v[0] * b.m[0][3]) + (this.v[1] * b.m[1][3]) + (this.v[2] * b.m[2][3]) + (this.v[3] * b.m[3][3]))
    );
    return dst;
  }

  this.ToString = function () {
    var s = this.v[0].toPrecision(3) + ',' + this.v[1].toPrecision(3) + ',' + this.v[2].toPrecision(3);
    return s;
  }
}